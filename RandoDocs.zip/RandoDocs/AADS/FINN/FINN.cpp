/*
Author : Ashton Spina
S - number:       s2906279
Date : 15 - 02 - 2017
Challenge : FINN

This program takes in an integer for how many inputs will exist as well 
initial skill.  Then follows a list of n three integer inputs with:
type | difficulty | experience gain
And outputs how many can be be completed by alternating task type

Time complexity : O(n^2)
The actualy time complexity is actually something like n(n+1)/2 which is considerably better
than n^2 might let on, but since it is in fact O(n^2) that is the final complexity.

Memory complexity : O(n)
If there are n lines of input then this program stores n lines of input.
It is slightly optimized in that it only stores 2 values per line instead of
3 as might be expected.
*/
#include <iostream>
#include <algorithm>
#include <set>

//a pair of difficulty and experience gain for easy management.  Pairs also have their own comparator.
typedef struct pair
{
	int diff, exp;//difficulty, experience gain
	bool operator==(const pair& a) const //override == operator
	{
		return (diff == a.diff && exp == a.exp);
	}
} pair;

//give the set a way to compare pairs
bool operator<(const pair &a, const pair &b)
{	//if the experience gain is the same, put the item with lower difficulty first for increased speed in iterative search
	return (a.exp > b.exp) || (a.exp == b.exp && a.diff < b.diff);
}

/*
This function takes either the multiset of type zeroes or the
multiset of type ones and finds a doable task with the highest experience
gain because the set is already ordered by experience gain.
This is an iterative search.  It then removes the item from the multiset in O(1) time.
*/
int completeTask(std::multiset< pair >& typeAny, int& tasks, int& skill)
{
	for(auto it : typeAny)
	{
		if(it.diff <= skill)
		{
			++tasks;
			skill += it.exp;
			typeAny.erase(it);
			return 0;
		}
	}
	return 1;
}
/*
This function attempts to do alternating typeOne and TypeZero tasks until
it cannot do any more and returns how many it completed.  The starting type 
is based on the type parameter
*/
int tasksCompleted(std::multiset < pair > typeZero, std::multiset < pair > typeOne, int type, int skill)
{

	int tasks = 0;
	while((!typeZero.empty()) || (!typeOne.empty()))
	{
		if(type)
		{
			if(completeTask(typeOne, tasks, skill)) 
				return tasks;
		}
		else
		{
			if(completeTask(typeZero, tasks, skill)) 
				return tasks;
		}

		type = 1 - type;
	}
	return tasks;
}

int main()
{
	std::ios::sync_with_stdio(false);
	pair hold;
	int numChallenges, initialSkill, type;
	std::cin >> numChallenges >> initialSkill;
	std::multiset< pair > typeZero,typeOne;
	
	for(int i = 0; i < numChallenges; ++i)
	{
		std::cin >> type >> hold.diff >> hold.exp;
		//insert into different multisets based on type
		//this eliminates the need to store or search based
		//on type
		if(type) typeOne.insert(hold);
		else typeZero.insert(hold);
	}
	//Call the function twice starting with a different type and compare the results.
	int resultOne = tasksCompleted(typeZero, typeOne, 0, initialSkill);
	int resultTwo = tasksCompleted(typeZero, typeOne, 1, initialSkill);
	//display lower result first
	resultOne > resultTwo ? std::cout << resultOne << std::endl : std::cout << resultTwo << std::endl;
	
	return 0;
}
