/*
Author : Ashton Spina
S - number:       s2906279
Date : 15 - 02 - 2017
Challenge : PLAY

Description here

Time complexity : O(n)


Memory complexity : O(n)

*/
#include <iostream>
#include <algorithm>
#include <unordered_set>

int main()
{
	std::ios::sync_with_stdio(false);
	int n, m, hold;
	long a, b, c, d, e;
	
	std::cin >> n >> m >> a >> b >> c >> d >> e;
	
	std::unordered_set< int > requestList;
	requestList.reserve(n);
	
	for(int i = 0; i < n; ++i)
	{
		std::cin >> hold;
		requestList.emplace(hold);
	}
	int count = 0;
	
	if(requestList.find(a) != requestList.end())
	{
			++count;
			requestList.erase(a);
	}
	if(requestList.find(b) != requestList.end())
	{
			++count;
			requestList.erase(b);
	}
	for(int i = 2; i < m; ++i)
	{
		hold = ((b * c) % e + (a * d) % e) % e;
		a = b;
		b = hold;
		
		if(requestList.find(hold) != requestList.end())
		{
			++count;
			requestList.erase(hold);
		}
	}
	std::cout << count << std::endl;
    
	return 0;
}
