/*
Author : Ashton Spina
S - number:       s2906279
Date : 15 - 02 - 2017
Challenge : PLAY

Description here

Time complexity : O(n)


Memory complexity : O(n)

*/
#include <iostream>
#include <algorithm>
#include <vector>
#include <unordered_map>

int main()
{
	std::ios::sync_with_stdio(false);
	int n, m, hold;
	long a, b, c, d, e;
	
	std::cin >> n >> m >> a >> b >> c >> d >> e;
	
	std::vector< int > requestList;
	requestList.resize(n);
	
	for(int i = 0; i < n; ++i)
	{
		std::cin >> hold;
		requestList.at(hold)
	int count = 0;
	auto got = requestList.find(a);
	if(got != requestList.end())
	{
			++count;
			requestList.erase(got);
	}
	got = requestList.find(b);
	if(got != requestList.end())
	{
			++count;
			requestList.erase(got);
	}
	for(int i = 2; i < m; ++i)
	{
		hold = ((b * c) % e + (a * d) % e) % e;
		a = b;
		b = hold;
		got = requestList.find(hold);
		if(got != requestList.end())
		{
			++count;
			requestList.erase(got);
		}
	}
	std::cout << count << std::endl;
    
	return 0;
}
