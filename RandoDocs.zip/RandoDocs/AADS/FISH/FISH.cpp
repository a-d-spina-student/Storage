/*
Author : 			Ashton Spina
S - number:       	s2906279
Date : 				17 - 03 - 2017
Challenge : 		FISH

Ponds are represented by the number 2
Fishermen's huts are represented by the number 1
Fields are represnted by the number 0

Finds shortest path moving in any of the 8 directions from 1s to 2s

Time complexity : O(n * m)
The time complexity is actually like worst case 8 actions per point in the matrix, but
by queueing up the states it ensures that theres worst case 8 actions per point and no more
because paths will be cut off.

Memory complexity : O(n*m + p)
I store n*m size matrix and p fisherman's huts.  whichever is more significant depends
on the input values.

*/

#include <iostream>
#include <vector>
#include <utility>
#include <limits>
#include <deque>

void findShortestPaths(std::deque< std::pair<int, int> > &toCheck, std::vector< std::vector< int > > &markingMatrix, int n, int m)
{
	std::pair<int, int> front;
	while(!toCheck.empty())//continue until the entire queue is empty
	{
		front = toCheck.front();
		toCheck.pop_front();
		//All these if statements check the 8 points around the center point removed from the front of the deque
		//They must also check that they're within the bounds of the matrix so that's why there's so many conditions.
		if(front.first + 1 < n)
		{
			if(front.second + 1 < m && markingMatrix[front.first + 1][front.second + 1] > markingMatrix[front.first][front.second] + 1)
			{
				markingMatrix[front.first + 1][front.second + 1] = markingMatrix[front.first][front.second] + 1;
				toCheck.push_back(std::pair<int, int> (front.first + 1, front.second + 1));
			}
			if(markingMatrix[front.first + 1][front.second] > markingMatrix[front.first][front.second] + 1)
			{
				markingMatrix[front.first + 1][front.second] = markingMatrix[front.first][front.second] + 1;
				toCheck.push_back(std::pair<int, int> (front.first + 1, front.second));
			}
		}

		if(front.first - 1 >= 0)
		{
			if(front.second - 1 >= 0 && markingMatrix[front.first - 1][front.second - 1] > markingMatrix[front.first][front.second] + 1)
			{
				markingMatrix[front.first - 1][front.second - 1] = markingMatrix[front.first][front.second] + 1;
				toCheck.push_back(std::pair<int, int> (front.first - 1, front.second - 1));
			}
			if(markingMatrix[front.first - 1][front.second] > markingMatrix[front.first][front.second] + 1)
			{
				markingMatrix[front.first - 1][front.second] = markingMatrix[front.first][front.second] + 1;
				toCheck.push_back(std::pair<int, int> (front.first - 1, front.second));
			}
		}

		if(front.second + 1 < m)
		{
			if(markingMatrix[front.first][front.second + 1] > markingMatrix[front.first][front.second] + 1)
			{
				markingMatrix[front.first][front.second + 1] = markingMatrix[front.first][front.second] + 1;
				toCheck.push_back(std::pair<int, int> (front.first, front.second + 1));
			}
			if(front.first - 1 >= 0 && markingMatrix[front.first - 1][front.second + 1] > markingMatrix[front.first][front.second] + 1)
			{
				markingMatrix[front.first - 1][front.second + 1] = markingMatrix[front.first][front.second] + 1;
				toCheck.push_back(std::pair<int, int> (front.first - 1, front.second + 1));
			}
		}

		if(front.first + 1 < n && front.second - 1 >= 0)
		{
			if(markingMatrix[front.first][front.second - 1] > markingMatrix[front.first][front.second] + 1)
			{
				markingMatrix[front.first][front.second - 1] = markingMatrix[front.first][front.second] + 1;
				toCheck.push_back(std::pair<int, int> (front.first, front.second - 1));
			}

			if(markingMatrix[front.first + 1][front.second - 1] > markingMatrix[front.first][front.second] + 1)
			{
				markingMatrix[front.first + 1][front.second - 1] = markingMatrix[front.first][front.second] + 1;
				toCheck.push_back(std::pair<int, int> (front.first + 1, front.second - 1));
			}
		}
	}
}

int main()
{
	std::ios::sync_with_stdio(false);
	int n, m, p, hold, min;
	std::cin >> n >> m >> p;
	std::deque< std::pair<int, int> > toCheck;//deque to ensure n*m checks
	std::vector< std::pair<int, int> > residences;//store residences to check at the end
	std::vector<std::vector<int>> markingMatrix (n, std::vector<int>(m, std::numeric_limits<int>::max()));//marking matrix initalized to MAX_INT
	for(size_t i = 0; i < n; ++i)
	{
		for(size_t j = 0; j < m; ++j)
		{
			std::cin >> hold;
			if(hold == 1)
				residences.push_back(std::pair<int, int> (i, j));
			if(hold == 2)
			{
				toCheck.push_back(std::pair<int, int> (i, j));
				markingMatrix[i][j] = 0;
			}
		}
	}

	findShortestPaths(toCheck, markingMatrix, n, m);
	for(auto it : residences)
		std::cout << markingMatrix[it.first][it.second] << std::endl;

	return 0;
}
