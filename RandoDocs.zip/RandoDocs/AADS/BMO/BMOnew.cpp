/*
Author : Ashton Spina
S - number:       s2906279
Date : 15 - 02 - 2017
Challenge : BMO

This program reads in an integer n first.  Then it reads in n*n values.  It then counts
how many of each i * i size square can be made using the input matrix of 0s and 1s.

Time complexity : O(n^2)
n^2 because for the dimension n I process n*n values.  If you consider there to simply be n inputs
then it is linear n for the n input values.  There is definitely some hefty constant in front of the
complexity value because I take a lot of actions on each input, but nonetheless, that's the answer.

Memory complexity : O(n)
Worst case 3n during the move. Most of the time 2n Because I only store two vectors.
*/
#include <iostream>
#include <vector>
#include <limits.h>
//checks the size of Square that can be made at a given position
int checkValues(std::vector< int >& previousLine, std::vector< int >& currentLine, int position, int n)
{
	if(!position || previousLine.empty())
		return 1;
	int min = INT_MAX;

	if(previousLine[position - 1] < min) min = previousLine[position - 1];
	if(previousLine[position] < min) min = previousLine[position];
	if(currentLine.back() < min) min = currentLine.back();

	return min + 1;
}
//counts the squares that can be made and prints them
void countSquares()
{
	int n, squareSize, position = 0, hold;
	
	std::cin >> n;
	std::vector< int > results(n);//histogram of squares found

	std::vector < int > previousLine;//previous line of input to reference
	std::vector < int > currentLine;//current line being built
	previousLine.reserve(n);//reserve memory for speed
	currentLine.reserve(n);//^^

	for(int i = n * n; i > 0; --i)
	{
		std::cin >> hold;
		if(position == n)
		{//if i've finished a line shift currentLine to previousLine and reset position
			previousLine =  std::move(currentLine);
			position = 0;
		}
		if(hold)
		{//If I've read a 1 check what size of square I can make
			squareSize = checkValues(previousLine, currentLine, position, n);
			currentLine.push_back(squareSize);//push_back whatever value I found to the currentLine
			for(int i = (squareSize - 1); i >=0; --i)
				++results[i];//increase squares found for all counts of size squareSize and lower
		}
		else
			currentLine.push_back(hold);//just push back the 0
		++position;
	}
	for(int& n : results)//print results
		std::cout << n << std::endl;
}

int main()
{
	std::ios::sync_with_stdio(false);
	countSquares();
}