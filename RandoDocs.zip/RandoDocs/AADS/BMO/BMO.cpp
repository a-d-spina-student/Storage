/*
Author : Ashton Spina
S - number:       s2906279
Date : 15 - 02 - 2017
Challenge : BMO

Description here

Time complexity : O(n)


Memory complexity : O(n)

*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <math.h>
#include <limits.h>

void printMatrix(std::vector< std::vector<int> > input)
{
	for(unsigned i = 0; i < input.size(); ++i)
	{
		for(unsigned j = 0; j < input.size(); ++j)
		{
			std::cout << input[i][j];
		}
		std::cout << std::endl;
	}
}

void updateBack(std::vector< std::vector<int> > *maxSquareSize, int n)
{
	std::vector< int > results(n);
	int min = INT_MAX;
	for (int x = n - 1 ; x >= 0; --x)
	{
		for (int y = n - 1 ; y >= 0; --y)
		{
			if((x + 1 < n) && (y + 1 < n))
			{
				min = INT_MAX;
				if((*maxSquareSize)[x][y])
				{
					(*maxSquareSize)[x + 1][y] < min ? min = (*maxSquareSize)[x + 1][y] : min;
					(*maxSquareSize)[x][y + 1] < min ? min = (*maxSquareSize)[x][y + 1] : min;
					(*maxSquareSize)[x + 1][y + 1] < min ? min = (*maxSquareSize)[x + 1][y + 1] : min;
					
					if(min > 0)
					{
						(*maxSquareSize)[x][y] = min + 1;
					}
				}
			}
			for(int k = (*maxSquareSize)[x][y]; k > 0; --k)
			{
				++results[k - 1];
			}
		}
	}
	for(int i = 0; i < n; ++i)
	{
		std::cout << results[i] << std::endl;
	}
}

int main()
{
	std::ios::sync_with_stdio(false);
	int n;
	std::cin >> n;
	
	std::vector< std::vector<int> > maxSquareSize(n, std::vector<int>(n));
	
	bool hold;
	for(int i = 0; i < n; ++i)
	{
		for(int j = 0; j < n; ++j)
		{
			std::cin >> hold;
			if(hold)
			{
				maxSquareSize[i][j] = 1;
			}
		}
	}
	updateBack(&maxSquareSize, n);
}
