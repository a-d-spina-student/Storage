/*
Author : 			Ashton Spina
S - number:       	s2906279
Date : 				08 - 03 - 2017
Challenge : 		TRAP

This takes in n coordinates and calculates how many trapeziums can be generated
with this points.  This is done by understandin that any two identical slopes 
between points indicates a trapezium can be formed.  Knowing this, I simply
Gauss Sum the  count of identical slopes for each unique slope and Sum all these 
sums to get an answer.

Time complexity : O(n * n)
Its actually Gauss Sum operations (n * (n - 1) ) / 2 
but officially its O(n ^ 2) because of this.


Memory complexity : O(n * n)
There are worst case all unique slopes for every operation done
which means that worst case I store Gauss Sum unique counts in 
my histogram so memory complexity also O(n ^ 2).
*/
#include <iostream>
#include <vector>
#include <limits>
#include <utility>
#include <unordered_map>

int checkParallel(std:: vector< std::pair< int, int > > coordinates, int n)
{
	std::unordered_map< double, int > slopeValues;//The map acts as a histogram of the correct size
	int countParallel = 0;
	double tempSlope, denominator;
	//These loops compare every point with ever other point after it so no point is compared
	//with itself or multiple times with any point
	for(int i = 0; i < n; ++i)
	{
		for(int j = i + 1; j < n; ++j)
		{
			denominator = coordinates[j].first - coordinates[i].first;
			if(!denominator)//check if the denominator is 0.  C++ handles this but in different ways so this gives it a standardized way to give a correct answer
				tempSlope = std::numeric_limits< double >::max();
			else
				tempSlope = (coordinates[j].second - coordinates[i].second) / denominator;		
			++slopeValues[tempSlope];//increase count in histogram
		}
	}
	//for each count in the histogram do the Gauss Sum to represent the possible formable trapeziums from those equal slopes
	for(auto countSame : slopeValues)
		countParallel += (countSame.second * (countSame.second - 1))/2;
	return countParallel;
}

int main()
{
	std::ios::sync_with_stdio(false);
	
	int n;
	std::vector< std::pair<int, int> > coordinates;
	std::pair<int, int> hold;
	std::cin >> n;
	for(int i = 0; i < n; ++i)
	{
		std::cin >> hold.first >> hold.second;
		coordinates.push_back(hold);
	}
	std::cout << checkParallel(coordinates, n) << std::endl;
	return 0;
}
