/*
Author : 			Ashton Spina
S - number:       	s2906279
Date : 				12 - 03 - 2017
Challenge : 		HOME

This program takes in a number n and then n + 1 values.  
Those values represent n matrices where matrix dimensions are 
inputs[i] * inputs[i + 1].  It then calculates the minimum number of scalar
multiplications to multiply all the matrices together.

I used this to understand the problem
http://philipmjohnson.org/ics311s14/morea/120.dynamic-programming/experience-2.html

Time complexity : O(n * n * n)
The time complexity is pretty difficult to decipher
The loops are essentially (n * (n - 1) * (n - 1))/2)) or similar
because the outer loop goes essentially a full n,
the middle loop with the outer sum is the Gauss Sum number of operations,
and the inner loop is the middle loop again every time.  Either way that makes it 
O(n^3) even though its not actually that amount of operations.


Memory complexity : O(n*n)
I only store a matrix of size n * n so that's officially the order of the 
memory complexity.
*/
#include <iostream>
#include <vector>
#include <limits>

/*
This function makes a marking matrix of size_t values called costMatrix
which marks the costs associated with multiplying the matrices in different orders.
If it finds a better cost for multiplying a subset of the total matrices 
it marks the better cost for that subset.  As such, the algorithm does not need to 
recompute optimal scalar multiplications for subsets of the total amount of matrices.
*/
size_t CalculateMinScalarOperations(std::vector<size_t> inputs, size_t n)
{	
	//This vector doesn't use its 0th row and column for simplicity of math because
	//n is weird and is actually kind of an n + 1 which offsets everything.
	std::vector< std::vector< size_t > > costMatrix(n, std::vector< size_t >(n));
 
    for (size_t chainLength = 2; chainLength < n; ++chainLength)
    {
        for (size_t i = 1; i < n - chainLength + 1 ; ++i)
        {
            size_t j = i + chainLength - 1;
            costMatrix[i][j] = SIZE_MAX;
            for (size_t k = i; k <= j - 1; ++k)
            {
                //costCurrentMulti = cost of scalar multiplications
                size_t costCurrentMulti = costMatrix[i][k] + costMatrix[k + 1][j] + inputs[i - 1] * inputs[k] * inputs[j];

                if (costCurrentMulti < costMatrix[i][j])
                    costMatrix[i][j] = costCurrentMulti;
            }
        }
    }
    return costMatrix[1][n-1];
}

int main()
{
	std::ios::sync_with_stdio(false);
	
	size_t n, hold;
	std::vector< size_t > inputs;
	std::cin >> n;
	++n;
	for(size_t i = 0; i < n; ++i)
	{
		std::cin >> hold;
		inputs.push_back(hold);
	}
	std::cout << CalculateMinScalarOperations(inputs, n) << std::endl;
	return 0;
}
