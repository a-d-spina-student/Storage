/*
Author : Ashton Spina
S - number:       s2906279
Date : 15 - 02 - 2017
Challenge : JAKE

I did some reading online and after reading some papers on partition problems I realized that 
this problem can be solved as more of a partition problem then a knapsack problem.  Rather, how can
I divide the subsets such that I get as close to even as possible.  So, I create a vector of booleans,
(though actually chars because char is faster than bool in c++ vectors, though less speed), to mark 
what sums I can create.  I then calculate the smallest difference I can create to approximately half 
of the total sum of items in order to get the best partition possible.  Whatever my closes sum to half I
can get is, the total sum - closest sum is the other subset sum.

Time complexity : O(n*sum(n))
The time complexity of this function is n*sum(n) because I make a vector of the size
sum + 1 in order to mark which sums can be created with the subsets.  For n items I will do 
the value of each n iterations I end up with this complexity.

Memory complexity : O(n)
n + sum(n) is really how much memory I use.  The sum(n) will almost always be better than
*/

#include <iostream>
#include <math.h>
#include <limits.h>
#include <vector>

void calculateSumArray (std::vector< int> input , int n)
{
    int sum = 0;
    for(int& num : input)//calculate sum in order to know the total sum my subset can make.
        sum += num; 
    //this vector stores boolean values representing whether a of the input values can make a certain sum represented by the index in the vector
    std::vector< char > sumBoolArray(sum + 1);//vector of char to save space, vector of bool slow

    sumBoolArray[0] = 1;//can always make a sum of 0 with an empty set

    int diff = INT_MAX, largestSubsetSum;

    for(int& num : input)//for each number in the input
    {
        for(int j = sum ; j >= num ; j--)//check if there are existing sums to add it to
        {
            if(sumBoolArray[j - num] == 1)//if I find one mark that a new sum can be made
    			sumBoolArray[j] = 1;

            if( sumBoolArray[j] == 1 )
            {
                if( diff > abs( sum / 2 - j) )//see if this difference is better than the previous one
                {
                    diff = abs( sum / 2 - j );//assign the new least difference
                    largestSubsetSum = j;
                }
            }
        }
    }
    //print results in order
    int resultOne = abs(sum - largestSubsetSum), resultTwo = largestSubsetSum;
    resultOne > resultTwo 
            ? std::cout << resultTwo << " " << resultOne << std::endl 
            : std::cout << resultOne << " " << resultTwo << std::endl;
}

int main()
{
    int n, hold;
    std::cin >> n;
    std::vector< int > inputArray(n);
    for(int i = 0; i < n; i++)
    {
        std::cin >> hold;
        inputArray.push_back(hold);
    }
    calculateSumArray(inputArray, n);

    return 0;
}
