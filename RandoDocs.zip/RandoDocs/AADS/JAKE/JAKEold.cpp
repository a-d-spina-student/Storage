/*
Author : Ashton Spina
S - number:       s2906279
Date : 15 - 02 - 2017
Challenge : JAKE

Description here

Time complexity : O(n)


Memory complexity : O(n)

*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <math.h>
#include <unistd.h>

typedef struct pair {
	int one, two;
} pair;


void printMatrix(std::vector< std::vector<int> > input)
{
	for(unsigned i = 0; i < input.size(); ++i)
	{
		for(unsigned j = 0; j < input.size(); ++j)
		{
			std::cout << input[i][j];
		}
		std::cout << std::endl;
	}
}

pair fillKnapsacks(std::vector< int > input, pair currentBackpacks, int limit){
	if(input.empty())
		return currentBackpacks;
	
	pair resultOne = currentBackpacks, resultTwo = currentBackpacks;
	
	int hold = (int)input.back();
	input.pop_back();
	pair temp = {
					.one = (currentBackpacks.one + hold),
					.two = currentBackpacks.two
				};
	if(temp.one <= limit)
		resultOne = fillKnapsacks(input, temp, limit);
	temp.one = currentBackpacks.one;
	temp.two = currentBackpacks.two + hold;
	if(temp.two <= limit)
		resultTwo = fillKnapsacks(input, temp, limit);
	
	if(abs(resultOne.one - resultOne.two) > abs(resultTwo.one - resultTwo.two))
		return resultTwo;
	else
		return resultOne;
}

int main()
{
	std::ios::sync_with_stdio(false);
	int n, hold, sum = 0, max = 0;
	std::cin >> n;
	std::vector< int > coolItems; //vector of items

	for(int i = 0; i < n; ++i)
	{
		std::cin >> hold;
		sum += hold;
		hold > max ? max = hold : max;
		coolItems.push_back(hold);
	}
	sum = sum/2 + max; //max value in a backpack
	pair startingPacks;
	startingPacks.one = 0;
	startingPacks.two = 0;
	pair result = fillKnapsacks(coolItems, startingPacks, sum);
	result.one > result.two ? std:: cout << result.two << " " << result.one << std::endl : std:: cout << result.one << " " << result.two << std::endl;
	return 0;
}

