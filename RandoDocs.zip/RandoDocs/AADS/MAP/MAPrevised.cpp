/*
Author : Ashton Spina
S - number:       s2906279
Date : 03 - 03 - 2017
Challenge : MAP

This calculates the minimum possible overlap of a matrix of strings printed on itself.

Time complexity : O(n*m)
If there are n strings and they are of m width then the complexity is essentially 
worse case n*m because it has to check each letter twice so it goes through the 
whole matrix once.  If our input is just considered to be n letters then it is
O(n)

Memory complexity : O(m)
I only store one line of input at a time so the complexity is O(m)
*/
#include <iostream>
#include <algorithm>
#include <string>
#include <limits.h>

int main()
{
	std::ios::sync_with_stdio(false);
	int currentMinSize = INT_MAX, currentSize = 0, lines, width;//currentMinSize set to INT_MAX to avoid confusions with minimums.
	std::string tempLine, stringBuilder, reverseStringBuilder;//building the string forwards and backwards.
	
	std::cin >> lines >> width;//input n and m represented by lines and width here.
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');//ignore to the newline just incase inputs are weird.
	
	for(int i = 0; i < lines; ++i)
	{
		std::getline(std::cin, tempLine);//get a line of input and store it in tempLine
		for(int j = 0; j < width; ++j)
		{
			stringBuilder += tempLine.at(j);//build from the front.
			reverseStringBuilder = tempLine.at(width - 1 - j) + reverseStringBuilder;//build from the back
			if (!stringBuilder.compare(reverseStringBuilder) && j >= width/2)//this ensures overlap because of indexing
			{//if the strings are the same and are at least overlapping and not just touching I have found the minimum overlap for that line
				currentSize = stringBuilder.length();
				break;
			}
		}
		if(currentSize < currentMinSize)
			currentMinSize = currentSize;//save the minimum of all the minimum overlaps
		currentSize = 0;
		stringBuilder.clear();
		reverseStringBuilder.clear();
	}
		
	if(currentMinSize == INT_MAX)
		currentMinSize = width;//if I found no overlap then at least the string must be printed completely on top if itself.
	
	std::cout << currentMinSize << std::endl;
	return 0;
}
