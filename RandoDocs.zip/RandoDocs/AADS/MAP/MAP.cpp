/*
Author : Ashton Spina
S - number:       s2906279
Date : 15 - 02 - 2017
Challenge : PLAY

Description here

Time complexity : O(n)


Memory complexity : O(n)

*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <math.h>
#include <limits.h>
#include <set>
#include <unordered_map>


int main()
{
	std::ios::sync_with_stdio(false);
	int currentMinSize = INT_MAX, currentSize = 0, n, m;
	std::string tempLine, stringBuilder, reverseStringBuilder;
	
	std::cin >> n >> m;
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	
	for(int i = 0; i < n; ++i)
	{
		std::getline(std::cin, tempLine);
		for(int j = 0; j < m - 1; ++j)
		{
			if(!(m - 1 - j)) break;
			stringBuilder += tempLine.at(j);
			reverseStringBuilder = tempLine.at(m - 1 - j) + reverseStringBuilder;
			
			if (stringBuilder.compare(reverseStringBuilder) == 0 && j > 0)
			{
				std::cout << stringBuilder << " ==? " << reverseStringBuilder << std::endl;
				currentSize = stringBuilder.length();
			}
		}
		if(currentSize < currentMinSize)
			currentMinSize = currentSize;
		currentSize = 0;
		stringBuilder.clear();
		reverseStringBuilder.clear();
	}
	if(currentMinSize == INT_MAX)
		currentMinSize = 0;
	
	std::cout << currentMinSize << std::endl;
	return 0;
}
