/*
Author : 			Ashton Spina
S - number:       	s2906279
Date : 				17 - 03 - 2017
Challenge : 		STAR

This program takes in a series of problems and a time for a worker to enlist help and 
calculates the least amount of time it would take to complete all the problems

Time complexity : O(n*logn)
For n problems there must be n, log n insertions into the priority queue.

Memory complexity : O(n)
There is only a priority queue of size n.
*/
#include <iostream>
#include <queue>

int main()
{
	std::ios::sync_with_stdio(false);
	int n, enlistTime, hold;

	std::cin >> n >> enlistTime;
	
	std::priority_queue<int, std::vector<int>, std::greater<int> > problemCosts;//sort by lowest time value first.
	if(n == 0)//if there are no jobs there is no time.
	{
		std::cout << 0 << std::endl;
		return 0;
	}
	for(int i = 0; i < n; ++i)
	{
		std::cin >> hold;
		problemCosts.push(hold);//push everything into a priority queue
	}
	/*
		The queue is essentially a queue of time states.  The first state is with
		no enlistments completed.  There will be in a sense a large tree of problems to 
		be completed.  The last two problems will be completed at the same time because
		there will always be two workers at the end (by the nature of the way recruitment works).
		Because the queue is ordered with least first, I know that the last two are either equal or that 
		the top of the queue is less than the next item in the queue.  As such, I can say that this
		problem is redundant because it can be completed in the same or less time as the next item.  
		As such, I remove this item and add the second item back to the queue with enlistment time
		added on because I know that I will eventually need to enlist people to do these jobs.
		This state downheaps to its appropriate location and the original problem is again presented to the 
		machine.  In doing this it will eventually find the optimal path by computing whether
		completing a problem will take less time than lesser value problems + enlistTime.  
		By working backwards this way it is known which is the optimal value because at the end
		there will only be one value in the queue representing the largest value + any extra time
		that wasn't occurring during the time the largest problem was being solved.
	*/
	while(problemCosts.size() > 1)
	{
		problemCosts.pop();//eliminate lowest time state
		hold = problemCosts.top();
		problemCosts.pop();
		problemCosts.push(hold + enlistTime);//add enlistment time to next state and push it to the queue 
	}
	std::cout << problemCosts.top() << std::endl;//last remaining state is optimal
	return 0;
}
