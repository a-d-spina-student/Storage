/*
Author : 			Ashton Spina
S - number:       	s2906279
Date : 				17 - 03 - 2017
Challenge : 		STAR

Description here

Time complexity : O(n)


Memory complexity : O(n)

*/
#include <iostream>
#include <vector>
#include <limits>
#include <algorithm>
#include <deque>

int calculateTimeToComplete(std::deque< int > problemCosts, int n, int enlistTime)
{
	int timeCompleted = enlistTime;
	int timeToComplete = 0;
	int workers = 2;

	while(true)
	{

		if(problemCosts.empty())
		{
			std::cout << "no more problems, workers left: " << workers << std::endl;
			return timeCompleted + timeToComplete;
		}
		if(workers == 0)
		{
			std::cout << "no more workers, problems left: " << problemCosts.size() << std::endl;
			return timeCompleted + timeToComplete;
		}
		if(workers >= problemCosts.size())
		{
			std::cout << "Completed on workers == size: " << problemCosts.size() << " " << workers << std::endl;
			if(timeToComplete > problemCosts.front())
				return timeCompleted + timeToComplete;
			else
				return timeCompleted + problemCosts.front();
		}

		int temp = problemCosts.front();
		problemCosts.pop_front();

		if(!problemCosts.empty() && 2*(temp - problemCosts.front()) < enlistTime)
		{
			problemCosts.push_front(temp);
			timeCompleted += enlistTime;
			workers *= 2;
		}
		else
		{
			--workers;
			while(!problemCosts.empty() && temp == problemCosts.front())
			{
				if(workers > 1)
				{
					problemCosts.pop_front();
					--workers;
				}
			}
			timeCompleted += enlistTime;
			timeToComplete -= enlistTime;

			if(timeToComplete < 0) 
				timeToComplete = 0;
			if(temp > enlistTime)
			{
				if(temp - enlistTime > timeToComplete)
					timeToComplete = temp - enlistTime;
			}

			//enlist workers such that there won't be more than needed
			std::cout << (2 * workers) << " " << problemCosts.size() << std::endl;
			while(!problemCosts.empty() && (2 * workers) > problemCosts.size())
			{
				std::cout << "adjusting size" << std::endl;
				problemCosts.pop_front();
				--workers;
			}
			workers *= 2;


		}
		std::cout << "workers: " << workers << " time Completed: " << timeCompleted << " time to Complete: " << timeToComplete << " problems left: " << problemCosts.size() << std::endl;

	}
	return timeCompleted + timeToComplete;
}

int main()
{
	std::ios::sync_with_stdio(false);
	int n, enlistTime, hold;

	std::cin >> n >> enlistTime;
	
	std::deque< int > problemCosts;
	
	for(int i = 0; i < n; ++i)
	{
		std::cin >> hold;
		problemCosts.push_back(hold);
	}
	std::sort(problemCosts.begin(), problemCosts.end());
	std::cout << calculateTimeToComplete(problemCosts, n, enlistTime) << std::endl;

	return 0;
}
