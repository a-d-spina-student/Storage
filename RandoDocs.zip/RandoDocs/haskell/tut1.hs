numberRoots :: Float -> Float -> Float -> Float
numberRoots a b c
 | delta < 0 = 0
 | delta == 0 = 1
 | otherwise = 2
  where delta = b*b - 4*a*c 

smallerRoot :: Float -> Float -> Float -> Float
smallerRoot a b c
 | nr == 0 = 0
 | nr == 3 = 0
 | otherwise = (-b - sqrt(b*b - 4*a*c))/(2*a)
  where nr = numberRoots a b c

powerTwo :: Int -> Int
powerTwo n
 | if n % 2 == 0 then m = 
 
