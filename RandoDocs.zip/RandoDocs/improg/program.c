#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char* argv[]){
	int divisorFlag, n,final, countFinal, i;
	scanf("%d",&final);
	n = 1;
	countFinal = 1;
	while(countFinal<=final){
		n += 2;
		divisorFlag = 0;
		for(i = 3; i*i<=(n+2); i+=2){
			if(n % i == 0 || (n + 2) % i == 0){
				divisorFlag = 1;
				break;
			}
		}
		if(!divisorFlag){
			countFinal++;
		}
	}
	printf("%d %d\n", n, (n+2));
	return 0;
}

