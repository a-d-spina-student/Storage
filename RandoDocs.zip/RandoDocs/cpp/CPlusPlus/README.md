# CPlusPlus
Projects and assignments concerning the 'Introduction to C++' course
