#include <iostream>
#include <string>
#include <cstdlib>

enum Mode
{
	WORDS = 'w',
	LINES = 'l',
	BYTES = 'b'
};

void countWords()
{
	std::string dummy;
	std::cin >> dummy;
}

void countLines()
{
	std::string dummy;
	std::getline(std::cin, dummy);
}

void countBytes()
{
	char dummy;
	std::cin.get(dummy);
}

void error()
{
	std::cout << "This is not a valid command.\n";
	exit(0);
}

int main(int argc, char *argv[])
{
	void (*action)();
	switch(argv[1][0])
	{
		case WORDS:
			action = countWords;
			break;
		case LINES:
			action = countLines;
			break;
		case BYTES:
			action = countBytes;
			break;
		default:
			error();
	}
	int count = 0;
	while(!std::cin.eof())
	{
		action();
		++count;
	}
	// count must be decremented by 1 because it 
	//  also counted the end of file 
	std::cout << count-1 << '\n';
}
