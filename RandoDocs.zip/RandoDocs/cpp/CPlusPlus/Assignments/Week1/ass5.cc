#include <iostream>
#include <string>

enum Type
{
	UNKNOWN = 0,
	ERROR = 1,
	OK = 2
};

int main()
{
	const size_t INSTRUCTION_SIZE = 3;
	int var = 0;
	int arg;
	Type status;
	std::string instruction;

	while (true)
	{
		status = OK;
		std::cout << '>';
		std::cin >> instruction;
		if (instruction.length() < INSTRUCTION_SIZE) 	// not a command, ignore it to
			continue;									// prevent segfault

		if (instruction[INSTRUCTION_SIZE - 1] == 't')	//'ret' stops the program, cannot be
			exit(OK);									// put in switch statement because it
														// does not expect an argument
		std::cin >> arg;
		switch (instruction[INSTRUCTION_SIZE - 1])
		{
			case 'o':									//'sto', stores a value in var 
				var = arg;
			break;	
			case 'd':									//'add', adds a value to var
				var += arg;
			break;
			case 'b':									//'sub' substracts a value from var
				var -= arg;
			break;
			case 'l':									//'mul' multiplies a value with var
				var *= arg;
			break;
			case 'v':									//'div' divides var with a value
				if(arg != 0)
					var /= arg;
				else
					status = ERROR;
			break;
			default:
				status = UNKNOWN;
				std::cout << "Unknown command";
		}
		std::cout << var << "\t\tStatus:" << status << '\n';
	}
}
