#include <iostream>
#include <string>

int main()
{
	std::string line;
	std::cin >> line;
	std::cout << '`' << line << "'\n";
}
