#include <iostream>

int main(int argc, char *argv[])
{
	size_t iteration = 0;
	size_t size = argc - 1;
	size_t powerOf2 = 1;
	while (iteration != powerOf2)
	{
		powerOf2 = 1;
		std::cout << iteration << ':';
		for (size_t index = 0; index < size; ++index)
		{
			if (iteration & powerOf2)
				std::cout << ' ' << argv[index + 1];
			powerOf2 *= 2;
		}	
		std::cout << '\n';
		++iteration;
	}
}
