#include <iostream>

int main(int argc, char *argv[])
{
	size_t subsetNumber = 0;
	size_t current = 0;
	size_t size = argc - 1;
	bool *present = new bool[size];
	while(current < size)
	{
		std::cout << ++subsetNumber << ':';
		for(size_t index = 0; index < size; ++index)
			if(present[index])
				std::cout << ' ' << argv[index + 1];
		std::cout << '\n';
		current = 0;
		while(current < size && !(present[current] = !present[current]))
			++current;
	}
	delete[] present;
}
