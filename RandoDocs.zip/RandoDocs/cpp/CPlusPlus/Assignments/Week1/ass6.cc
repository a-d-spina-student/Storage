#include <iostream>
#include <string>

enum Args 
{
	MinArgs = 3,
	FirstArg = 1,
	SecondArg = 2
};

int main(int argc, char *argv[])
{
	if (argc < MinArgs)			// Not enough arguments provided
		exit(1);

	int radix = std::stoi(argv[FirstArg]); 
	size_t val = std::stoi(argv[SecondArg]);
	std::string alphabet = "0123456789abcdefghijklmnopqrstuvwxyz";
	std::string result = "";

	while (val != 0) 
	{
		result = alphabet.at(val % radix) + result;
		val /= radix;
	}
	std::cout << val << ", displayed using radix " << val << " is: " <<
	 	 result << '\n';
}
