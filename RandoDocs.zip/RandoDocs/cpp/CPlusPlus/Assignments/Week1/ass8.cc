#include <iostream>
#include <string>

enum Clock
{
	CircleDegree= 360,
	Hour = 30,
	HalfHour = 15
};

int main()
{
	size_t angle; 
	std::string half;
	while (true)
	{
		std::cin >> angle;
		if (angle == 0)
			break;
		// round angle to nearest 15
		angle = (angle + HalfHour/2) / HalfHour * HalfHour; 
		if (angle == 0)
			angle += CircleDegree;
		half = angle % Hour ? "30" : "00";
		std::cout << "object at your " << angle / Hour <<
		 ':' << half  << " position\n";
	}
}
