#include "main.ih"

void usage()
{
    std::cout << "[PROGRAM NAME] V [VERSION] \n\n" <<
            "Usage: [PROGRAM NAME] [options] < " <<
            "file\nWhere:\n--capitalize (--uc, -c);" <<
            "captitalize the letter\n" <<
            "--captitalize (--uc, -c);   captitalize the " <<
            "letters in 'file'\n" <<
            "--lower-case (--lc, -l) convert the letters in file " <<
            "to lower-case\n --version (-v) shows version number\n" <<
            "--help (-h) provides program usage information\n\n" <<
            "[PROGRAM NAME] processes 'file' and writes " <<
            "the results to the standard output stream.\n";
}
