#include "main.ih"

unsigned long long fib(unsigned long long value)
{
	unsigned long long fibval[value + 1];
	for(int i = 0; i < value + 1; ++i)
	{
		fibval[i] = 0;
	}
	return fibValWArr(value, fibval);
}
