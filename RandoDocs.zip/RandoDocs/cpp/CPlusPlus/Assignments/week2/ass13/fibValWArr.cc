#include "main.ih"

unsigned long long fibValWArr(unsigned long long value, unsigned long long *fibval)
{
	if (value < 3) return 1;
	if (fibval[value]) return fibval[value];
	fibval[value] = fibValWArr((unsigned long long) (value - 1), fibval) + fibValWArr((unsigned long long) (value - 2), fibval);
	return fibval[value];
}
