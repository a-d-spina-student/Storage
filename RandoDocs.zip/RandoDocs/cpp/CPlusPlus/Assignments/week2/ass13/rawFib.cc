#include "main.ih"

unsigned long long rawFib(unsigned long long value)
{
	if (value < 3) return 1;
	return rawFib(value - 1) + rawFib(value - 2);
}
