#include "main.ih"

int main(int argc, char *argv[])
{	
	unsigned long long value;
	char* end;
	if (argc > 2)
		std:: cout << rawFib(std::strtoull(argv[1], 0, 10)) << "\n";
	else 
		std:: cout << fib(std::strtoull(argv[1], 0, 10)) << "\n";
}
