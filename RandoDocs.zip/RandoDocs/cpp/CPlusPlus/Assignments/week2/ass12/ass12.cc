#include "main.ih"

int main(int argc, char *argv[])
{
	long long hold;
	std::cin >> hold;
	std::cout << "Recursive Version:  "; 
	printBig(std::cout, hold);
	std::cout << "\n";
	std::cout << "Brute Force Version:  ";
	rawPrintBig(std::cout, hold) ;
	std::cout << "\n";
}
