#include "main.ih"

void rawPrintBig(std::ostream &out, long long value)
{
	std::string store;
	int count = 0;
	long long hold = value;
	while (value)
	{
		store.insert(0, 1, ('0' + std::abs(value % TENTHS)));
		value /= TENTHS;
		++count;
		if (count == 3 && value) 
		{
			store.insert(0, 1, '\'');
			count = 0;
		}
	}
	if (hold < 0) store.insert(0, 1, '-');
	out << store;
}
