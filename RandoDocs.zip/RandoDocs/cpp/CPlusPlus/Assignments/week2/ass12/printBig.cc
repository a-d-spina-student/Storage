#include "main.ih"

void printBig(std::ostream &out, long long value)
{
	if (std::abs(value) < THOUSANDTHS)
	{
		out << value; 
		return;
	}
	printBig(out, value / THOUSANDTHS);
	int digits = std::abs(value % THOUSANDTHS);
	out << '\'' << (digits % THOUSANDTHS) / HUNDREDTHS 
				<< (digits % HUNDREDTHS) / TENTHS 
				<< digits % TENTHS;
}
