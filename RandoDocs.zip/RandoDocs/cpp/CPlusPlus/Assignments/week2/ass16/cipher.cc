#include "main.ih"

void cipher(Vars variables)
{
	string line;
	string encrypted;
	string alphabet = "\t\n !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
	int cipherType = 1;
	if (variables.action == DECRYPT)
		cipherType = -1;
	
	getline(cin, line);

	for (size_t index = 0; index != line.length(); ++index){
		int keyVal = cipherType * alphabet.find_first_of(variables.key.at(index % variables.key.length()));
		if (keyVal < 0)
			keyVal += alphabet.length();
		
		encrypted += alphabet.at((alphabet.find_first_of(line.at(index)) + keyVal)%alphabet.length());
	}
	
	cout << encrypted << '\n';
}
