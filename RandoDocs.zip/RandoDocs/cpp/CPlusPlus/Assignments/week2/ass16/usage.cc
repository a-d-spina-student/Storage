#include "main.ih"

void usage()
{
	cout << "vigcipher V 1.0\n\n" <<
		"Usage: vigcipher key [option] < inputFile > outputFile\n" <<
		"Encrypts text from the inputFile using the key.\n" <<
		"Where:\n -d : decrypts the inputFile with the given key\n" <<
		"-h : displays the usage of the program\n";
}
