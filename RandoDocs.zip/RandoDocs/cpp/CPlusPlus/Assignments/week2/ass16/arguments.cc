#include "main.ih"

Vars arguments(int argc, char **argv)
{
	Vars variables;
	size_t numArgs = 2;
	if(argv[1][1] == 'h')
		variables.action = USAGE;
	else
		variables.key = *argv;

	if(argc > numArgs)
		variables.action = DECRYPT;
		
	return variables;
}
