#include "main.ih"

void process(Vars variables)
{
	if (variables.action == USAGE)
		usage();
	else
		cipher(variables);
}
