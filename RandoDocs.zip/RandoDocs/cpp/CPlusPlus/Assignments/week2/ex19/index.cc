/* number of triangle elements on matrix row x: nFighters - x - 1
 * Sum of triangle elements from row 0 to row (one - 1):
 * (nFighters - 0 - 1) + (nFighters - 1 - 1) + ... + (nFighters - one - 1 - 1) ==
 * == one * (nFighters - 1) - one * (one - 1) / 2 = 
 * == one * (2 * nFighters - one - 1) / 2
 * Number of triangle elements in matrix row one, that are before column two:
 * two - one - 1 , where two > one
 * Actual index of distance between one and two:
 * sum of triangle elements from row 0 to row (one - 1) +
 * number of triangle elements in matrix row one, that are before column two
 * == one * (2 * nFighters - one - 1) / 2 + two - one - 1
 */

size_t index(size_t nFighters, size_t one, size_t two)
{
	if (one > two)
		return index(nFighters, two, one);
	return one * (2 * nFighters - one - 1) / 2 + two - one - 1;
}
