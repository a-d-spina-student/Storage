#include "main.ih"

void version()
{
    std::string versionNum= "1.0.0";
    std::cout << versionNum << '\n';
}