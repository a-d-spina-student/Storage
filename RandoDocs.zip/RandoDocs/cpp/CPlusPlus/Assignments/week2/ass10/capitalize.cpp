#include "main.ih"

void capitalize()
{
	std::string input;
	while (std::getline(std::cin, input))
	{
		std::string output;
		for (size_t index = 0; index < input.length(); ++index)
			output += toupper(input.at(index));
		std::cout << output << '\n';
	}


}