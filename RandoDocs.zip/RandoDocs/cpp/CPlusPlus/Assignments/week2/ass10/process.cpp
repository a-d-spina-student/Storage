#include "main.ih"

size_t process(Vars variables)
{
  if (isatty(STDIN_FILENO))
  {
    std::cout << "No file redirection\n";
    return 1;
  }

  switch (variables.m)
  {
    case ERROR:
      std::cout << "Improper argument specification\n";
      return 1;
    case USAGE:
      usage();
      break;
    case VERSION:
      version();
      break;
    case CAPITALIZE:
      capitalize();
      break;
    case LOWER_CASE:
      lowerCase();
      break;
    default:
      std::cout << "Error\n";
      break;
  }

  return 0;
}