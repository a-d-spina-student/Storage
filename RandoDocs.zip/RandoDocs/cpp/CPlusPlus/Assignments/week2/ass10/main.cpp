#include "main.ih"

int main(int argc, char **argv)
{
	Vars v;
	v.argc = argc;
	v.argv = argv;
	arguments(&v);
	return process(v);
}