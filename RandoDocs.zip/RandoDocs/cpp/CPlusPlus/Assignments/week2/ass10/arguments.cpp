#include "main.ih"

struct option longOpts[] =
{
  { "capitalize", 0, 0, 'c'},
  { "uc", 0, 0, 'c'},
  { "help", 0, 0, 'h'},
  { "version", 0, 0, 'v'},
  { "lc", 0, 0, 'l'},
  { "lower-case", 0, 0, 'l'},
  {0, }
};

void arguments(Vars *variables)
{
  
	int options;
  bool capitalize = false;
  bool help = false;
  bool version = false;
  bool lowerCase = false;

	while ((options = getopt_long (variables->argc, variables->argv, "chvl", longOpts, 0)) != -1)
    switch (options)
    {
  		case 'c':
  			capitalize = true;
  		  break;
    	case 'h':
      	help = true;
        break;
     	case 'v':
    		version = true;
    	 break;
   		case 'l':
        lowerCase = true;
        break;
      default:
     	  variables->m = OK;
        break;
    }

  

  if(help)
    variables->m = USAGE;
  else if (version)
    variables->m = VERSION;
  else if (capitalize)
    if(lowerCase)
      variables->m = ERROR;
    else
      variables->m = CAPITALIZE;
  else
    variables->m = LOWER_CASE;

}