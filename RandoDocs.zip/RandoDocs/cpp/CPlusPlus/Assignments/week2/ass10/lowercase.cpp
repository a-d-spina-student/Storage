#include "main.ih"

void lowerCase()
{
	std::string input;
	
	while (std::getline(std::cin, input))
	{
		std::string output;
		for (size_t index = 0; index < input.length(); ++index)
			output+= tolower(input.at(index));
		std::cout << output;
	}
}