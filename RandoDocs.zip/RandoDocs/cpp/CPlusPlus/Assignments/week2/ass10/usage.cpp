#include "main.ih"

void usage()
{
    std::string versionNum = "1.0.0";
    std::cout << "textEdit V " << versionNum << "\n\n" <<
            "Usage: <program's base name> [options] < " <<
            "file\nWhere:\n--capitalize (--uc, -c);" <<
            "captitalize the letter\n" <<
            "--captitalize (--uc, -c);   captitalize the" <<
            "letters in 'file'\n" <<
            "--lower-case (--lc, -l) convert the letters in file" <<
            "to lower-case\n --version (-v) shows version number\n" <<
            "--help (-h) provides program usage information\n\n" <<
            "<program's base name processes 'file' and writes" <<
            "the results to the standard output stream.\n";
}