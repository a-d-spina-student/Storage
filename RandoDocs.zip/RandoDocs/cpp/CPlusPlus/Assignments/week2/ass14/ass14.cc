#include "main.ih"

int main(int argc, char *argv[])
{
	QualityVariables status;
	initializeStatus(&status);
	readStringAndEval(&status);
	double dq;
	std::cout << status.commentValue;
	((status.lineCount) != 0) 
			? dq = ((double)(status.commentValue) / (double)(status.lineCount)) * 200 
			: dq = 0.0;
	if (dq > 100.0) dq = 100.0;
	std::cout << "Line Count: " << status.lineCount
				<< "\neoln Comments: " << status.tradComments 
				<< "\nC style Comments: " << status.cComments 
				<< "\nMax. Nest Level: " << status.maxNestLvl
				<< "\nDocument Quality: " << dq << "%\n";
}
