#include "main.ih"

void initializeStatus(QualityVariables *status)
{
	status->maxNestLvl = 0;
	status->currentNestLvl = 0;
	status->commentValue = 0;
	status->isStartofFile = false;
	status->linesIntoCComment = 0;
	status->tradComments = 0;
	status->cComments = 0;
	status->lineCount = 0;
	status->inCComment = false;
}
