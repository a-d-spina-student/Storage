#include "main.ih"

void setMaxNestLevel(QualityVariables *status)
{
	if (status->currentNestLvl > status->maxNestLvl) 
	{
		status->maxNestLvl = status->currentNestLvl;
	}
}
