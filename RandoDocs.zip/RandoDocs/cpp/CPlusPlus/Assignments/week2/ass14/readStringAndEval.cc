#include "main.ih"

void readStringAndEval(QualityVariables *status)
{
	char c;
	bool readFlag = true;
	while (c != EOF)
	{
		if (readFlag) c = getchar();
		readFlag = true;
		switch (c)
		{
			case '{':
				++(status->currentNestLvl);
				setMaxNestLevel(status);
				break;
			case '}':
				--(status->currentNestLvl);
				break;
			case '/':
				c = getchar();
				if (c == '/')
				{
					++(status->commentValue);
					++(status->tradComments);
				}
				else if (c == '*')
				{
					readFlag = false;
					if (status->lineCount == 1) status->isStartofFile = true;
					status->inCComment = true;
					++(status->linesIntoCComment);
				}
				break;
			case '*':
				if (!status->inCComment) break;
				c = getchar();
				readFlag = false;
				if (c == '/')
				{
					if (status->isStartofFile)
					{
						status->commentValue += status->linesIntoCComment;
						status->isStartofFile = false;
					}
					else ++(status->commentValue);
					++(status->cComments);
					status->inCComment = false;
				}
				break;
			case '\n':;
				if (status->lineCount > 30) 
				{
					(status->currentNestLvl > 3) ? status->lineCount += 4 : status->lineCount += 2;
				}
				else 
				{
					++(status->lineCount);
				}
				break;
		}	
	}
}