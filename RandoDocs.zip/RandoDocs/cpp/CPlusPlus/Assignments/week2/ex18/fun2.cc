#include <string>
#include "ex18.h"

void fun2(std::string const &s)
{
    size_t sum = 0;
    for (size_t idx = 0; idx < s.length(); ++idx)
        sum += s[idx];
} 
