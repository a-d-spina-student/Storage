#include "ex18.h"

int main(int argc, char *argv[])
{
    callValue(argv[0]);
    callRef(argv[0]);
}