/*
Author : 	Ashton Spina
Author : 	Alexandru Babeanu
Date : 		15 - 03 - 2017
Challenge : ex1
*/

#include <iostream>
#include <algorithm>
#include <vector>


int helperFunction(std::vector< size_t > &inputs, size_t idx, int lOne, int lTwo, size_t count)
{
	int storage;
	//std::cout << lOne << " " << lTwo << " " << count << std::endl;
	if(count == 4)
		return lOne * lTwo;
	if(idx == inputs.size())
		return -1;
	switch(count)
	{
		case 0:
			return std::max(helperFunction(inputs, idx + 1, lOne, lTwo, count), helperFunction(inputs, idx + 1, inputs[idx], lTwo, count + 1));
		case 1:
			storage = helperFunction(inputs, idx + 1, lOne, lTwo, count);
			return std::max(storage, (lOne == inputs[idx] ? helperFunction(inputs, idx + 1, lOne, lTwo, count + 1) : helperFunction(inputs, idx + 1, lOne, inputs[idx], count + 1)));
		case 2:
			if(lTwo == -1)
				return std::max(helperFunction(inputs, idx + 1, lOne, lTwo, count), helperFunction(inputs, idx + 1, lOne , inputs[idx], count + 1));
			else
			{
				if(inputs[idx] == lOne || inputs[idx] == lTwo)
				{
					return helperFunction(inputs, idx + 1, lOne, lTwo, count + 1);
				}
				return helperFunction(inputs, idx + 1, lOne, lTwo, count);
			}
		case 3:
			if(inputs[idx] == lOne || inputs[idx] == lTwo)
			{
				return helperFunction(inputs, idx + 1, lOne, lTwo, count + 1);
			}
			else
				return helperFunction(inputs, idx + 1, lOne, lTwo, count);
			break;	
	}

}


int main()
{
	std::ios::sync_with_stdio(false);
	size_t n, hold;

	std::cin >> n;

	std::vector< size_t > inputs;

	for(size_t i = 0; i < n; ++i)
	{
		std::cin >> hold;
		inputs.push_back(hold);
	}

	

	std::cout << helperFunction(inputs, 0, -1, -1, 0) << std::endl;

	return 0;
}
