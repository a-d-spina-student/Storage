/*
Author : 	Ashton Spina
Author : 	Alexandru Babeanu
Date : 		15 - 03 - 2017
Challenge : ex1
*/

#include <iostream>
#include <algorithm>
#include <vector>
#include <deque>
/*
void helperFunction(std::deque< size_t > &line, size_t idx, size_t sum[2])
{
	size_t holdSecond;
	if(!line.size())
		return;
	size_t sumHolder = sum[!idx], sumHolderTwo;
	size_t hold = line.front();
	sum[idx] += hold;
	line.pop_front();
	helperFunction(line, !idx, sum);
	sum[idx] -= hold;
	line.push_front(hold);
	holdSecond = line.back();
	sum[idx] += holdSecond;
	line.pop_back();
	sumHolderTwo = sum[!idx];
	sum[!idx] = sumHolder;
	helperFunction(line, !idx, sum);

	if(hold > holdSecond)
	{
		sum[!idx] = sumHolderTwo;
		sum[idx] += hold - holdSecond;
		line.push_back(holdSecond);
		line.pop_front();
	}

}*/

void helperFunction(std::deque< size_t > &line, size_t idx, size_t sum[2])
{
	size_t holdSecond;
	if(!line.size())
		return;
	size_t sumHolder = sum[!idx], sumHolderTwo;
	size_t hold = line.front();
	sum[idx] += hold;
	line.pop_front();
	helperFunction(line, !idx, sum);
	//std::cout << "Call one:" << sum[0] << " " << sum[1] << std::endl;
	sum[idx] -= hold;
	line.push_front(hold);
	holdSecond = line.back();
	sum[idx] += holdSecond;
	line.pop_back();
	sumHolderTwo = sum[!idx];
	sum[!idx] = sumHolder;
	helperFunction(line, !idx, sum);
	//std::cout << "Call two:" << sum[0] << " " << sum[1] << std::endl;

	if(hold > holdSecond)
	{
		sum[!idx] = sumHolderTwo;
		sum[idx] += hold - holdSecond;
		
	}
	line.push_back(holdSecond);
}


int main()
{
	std::ios::sync_with_stdio(false);
	size_t n;

	std::cin >> n;
	
	std::deque< size_t > line;
	line.push_back(1);
	for(size_t i = 1; i != n; ++i)
	{
		line.push_back((line.back() * line.back() + 98) % 10000019);
	}
    size_t sum[2] = {0, 0};
	helperFunction(line, 0, sum);

	std::cout << sum[0] << " " << sum[1] << std::endl;

	return 0;
}
