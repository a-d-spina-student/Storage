/*
Author : 	Ashton Spina
Author : 	Alexandru Babeanu
Date : 		15 - 03 - 2017
Challenge : ex1
*/

#include <iostream>
#include <algorithm>
#include <vector>

void helperFunction()
{





}


int main()
{
	std::ios::sync_with_stdio(false);
	size_t s, c, original, count = 0;

	std::vector< size_t > billStack;

	std::cin >> c >> s;
	billStack.push_back(1);
	billStack.push_back(c);
	original = c;
	while(c < s)
	{
		c *= original;
		billStack.push_back(c);
	}

	while(s)
	{
		if(billStack.back() > s)
		{
			if(count)
			{
				std::cout << count << "x" << billStack.back() << std::endl;
				count = 0;
			}
			billStack.pop_back();
		}
		else
		{
			s -= billStack.back();
			++count;
		}
	}
	if(count)
	{
		std::cout << count << "x" << billStack.back() << std::endl;
		count = 0;
	}



    
	return 0;
}
