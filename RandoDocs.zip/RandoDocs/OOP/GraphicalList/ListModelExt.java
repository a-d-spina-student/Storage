import java.util.ArrayList;

import javax.swing.AbstractListModel;


public class ListModelExt extends AbstractListModel<String> {
	
	private ArrayList<String> list;
	private int counter;
	
	public ListModelExt(){
		this.list = new ArrayList<String>();
		this.counter = 0;
		
		while(this.counter < 10){
			this.list.add("Element " + counter);
			this.counter++;
		}
	}

	@Override
	public String getElementAt(int index) {
		return this.list.get(index);
	}

	@Override
	public int getSize() {
		return this.list.size();
	}
	
	public void addElement(String s){
		this.list.add(s);
		this.counter++;
		this.fireContentsChanged(this, this.getSize() - 1, this.getSize());
	}
	
	public void removeElement(int index){
		this.list.remove(index);
		this.fireContentsChanged(this, 0, 1);
	}
	
	public int getCounter(){
		return this.counter;
	}

}
