import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;


public class ListPane extends JPanel {
	
	// private ListModelExt model;
	private ListModelInt model;
	private JList<String> list;
	
	public ListPane(){
		// this.model = new ListModelExt();
		this.model = new ListModelInt();
		this.list = new JList<String>(this.model);
		
		this.setLayout(new BorderLayout());
		JScrollPane pane = new JScrollPane(this.list);
		JButton addButton = new JButton("Add element");
		JButton removeButton = new JButton("Remove element");
		JButton printButton = new JButton("Print");
		
		/* Add actionListeners using anonymous inner classes */
		addButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				ListPane.this.model.addElement("Element " + ListPane.this.model.getCounter());
			}
		});
		
		removeButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				ListPane.this.model.removeElement(0);
			}
		});
		
		printButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				System.out.println("Selected items:");
				ListPane.this.printSelectedValues();
			}
		});
		
		this.list.addListSelectionListener(new ListSelectionListener(){
			@Override
			public void valueChanged(ListSelectionEvent e) {
				System.out.println("Selection changed:");
				ListPane.this.printSelectedValues();
			}
		});
		
		/* Add everything to JPanel */
		this.add(pane, BorderLayout.NORTH);
		this.add(addButton, BorderLayout.WEST);
		this.add(removeButton, BorderLayout.EAST);
		this.add(printButton, BorderLayout.SOUTH);
	}
	
	private void printSelectedValues(){
		for(String s: this.list.getSelectedValuesList()){
			System.out.println(s);
		}
	}

}
