import javax.swing.JFrame;


public class GraphicalList {
	
	public static void main(String[] args){
		JFrame frame = new JFrame("List model example");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new ListPane());
		frame.pack();
	    frame.setLocationRelativeTo(null);
		frame.setSize(270, 240);
		frame.setVisible(true);
	}

}
