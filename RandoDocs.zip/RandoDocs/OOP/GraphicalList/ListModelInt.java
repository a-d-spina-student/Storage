import java.util.ArrayList;

import javax.swing.ListModel;
import javax.swing.event.EventListenerList;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;


public class ListModelInt implements ListModel<String> {
	
	private EventListenerList listenerList;
	private ArrayList<String> list;
	private int counter;
	
	public ListModelInt(){
		this.listenerList = new EventListenerList();
		this.list = new ArrayList<String>();
		this.counter = 0;
		
		while(this.counter < 10){
			this.list.add("Element " + counter);
			this.counter++;
		}
	}

	@Override
	public void addListDataListener(ListDataListener l) {
		this.listenerList.add(ListDataListener.class, l);
	}

	@Override
	public String getElementAt(int index) {
		return this.list.get(index);
	}

	@Override
	public int getSize() {
		return this.list.size();
	}

	@Override
	public void removeListDataListener(ListDataListener l) {
		this.listenerList.remove(ListDataListener.class, l);
	}
	
	protected void isChanged(){
		ListDataEvent event = new ListDataEvent(this, ListDataEvent.CONTENTS_CHANGED, 1, this.getSize());
		/* Notify all listeners that model has changed */
		for(ListDataListener l : this.listenerList.getListeners(ListDataListener.class)){
			l.contentsChanged(event);
		}
	}
	
	public void addElement(String s){
		this.list.add(s);
		this.counter++;
		this.isChanged();
	}
	
	public void removeElement(int index){
		this.list.remove(index);
		this.isChanged();
	}
	
	public int getCounter(){
		return this.counter;
	}

}
