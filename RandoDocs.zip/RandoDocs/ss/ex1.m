% author 1: Alexandru Babeanu (s3004872)
% author 2: Ashton Spina (s2906279)

function cor = circorr(x,y)

	lenx = length(x);

	if (lenx != length(y))
		error('circorr(x,y): x and y are not of the same length');
	end

	cor = repmat(0, 1, lenx);

	for i = 1:lenx
		for j = 1:lenx
			cor(i) += x(j) * y(1 + mod(i + j - 1, lenx));
		end
	end

end

function r = rotate(x, n)

	r = circshift(x', n)';

end

function pc = pearson(x, y)

	lenx = length(x);  % number of samples
	if (lenx ~= length(y))
	error('pearson(x,y): x and y are not of the same shape');
	end
	x = x - sum(x)/length(x);
	y = y - sum(y)/length(y);
	denom = norm(x)*norm(y);
	y = y(end:-1:1);    % reverse of y
	% use convolution theorem: pc=conv(x,y)
	pc = real(ifft(fft(x).*fft(y)));
	pc = [pc(lenx), pc(1:lenx-1)] / denom;

end

function cor = circpearson(x, y)

	lenx = length(x);
	leny = length(y);

	if lenx != leny
		error('circorr(x,y): x and y are not of the same length');
	end

	x = x - sum(x) / lenx;
	y = y - sum(y) / leny;

	denom = sqrt(sum(x.^2)) * sqrt(sum(y.^2));

	cor = repmat(0, 1, lenx);

	if denom == 0
		return;
	end

	for i = 1:lenx
		for j = 1:lenx
			cor(i) += x(j) * y(1 + mod(i + j - 2, lenx));
		end
	end

	cor = cor / denom;

end

function samples = sinusoid2samples(amplitude, omega, phi, samplerate)
	for k = 0:samplerate
		samples(k + 1) = amplitude * cos(omega * k / samplerate + phi);
	end
end

%%%%%%% main program starts here %%%%%%%

x = rand(1, 100);
y = rotate(x, 50);

cor = circpearson(x, x);
plot(cor);
pause();

cor = circpearson(x, x + rand(1,100)*0.1);
plot(cor);
pause();

cor = circpearson(x, x + rand(1,100)*0.3);
plot(cor);
pause();

cor = circpearson(x, x + rand(1,100)*0.5);
plot(cor);
pause();

cor = circpearson(x, x + rand(1,100));
plot(cor);
pause();


%{
moment = time();
cor = circpearson(x, y);
moment = time() - moment
plot(cor);
pause();
moment = time();
cor = pearson(x, y);
moment = time() - moment
plot(cor);
pause();

a = sinusoid2samples(2, 10, 0, 100);
b = sinusoid2samples(50, 10,-(1 / 2 * pi), 100);
plot(a);
pause();
plot(b);
pause();
plot(pearson(a, b));
pause();
%}
