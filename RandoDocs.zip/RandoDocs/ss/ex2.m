% author 1: Alexandru Babeanu (s3004872)
% author 2: Ashton Spina (s2906279)

function avg = runningAvg(x, avgSize)
	lenX = length(x);
	
	if(avgSize > lenX)
		error("Averager size bigger than array size");
	end
	
	circSum = sum(x(1:(avgSize - 1)));
	
	j = 1;
	for i = avgSize : lenX
		circSum += x(i);
		avg(j) = circSum / avgSize;
		circSum -= x(j);
		++j;
	end
	
end

function cor = circpearson(x, y)

	lenX = length(x);
	lenY = length(y);
	
	if lenX < lenY
		z = x;
		x = y;
		y = z;
		lenZ = lenX;
		lenX = lenY;
		lenY = lenZ;
	end
	
	x = horzcat(x, x(1:(lenY - 1)));
	meanX = runningAvg(x, lenY);
	
	y = y - sum(y)/lenY;
 	denomY = sqrt(sum(y.^2));
	
	cor = zeros(1, lenX);
	
	for i = 1:lenX
		xd = x(i:(i + lenY - 1)) - meanX(i);
	    denom = (sqrt(sum(xd.^2))) * denomY;
	    if denom
			cor(i) = dot(xd, y)/denom;
		else
			cor(i) = 0;
		end
	end
end

function cor = patternMatch(x, h, avgSize = 10)
	cor = circpearson(runningAvg(x, avgSize), runningAvg(h, avgSize));
end

function cor = patternMatch2D(x, h, avgSize)
	cor = normxcorr2(h, x);
end

%{
x = repmat(0, 1, 150);
x(50) = 1;
x(100) = 1;
m = repmat(0, 1, 70);
n = repmat(0, 1, 70);
m(10) = 1;
m(60) = 1;
n(10) = 1;
n(59) = 1;
plot(circpearson(x, m));
pause();
plot(circpearson(x, n));
pause();
plot(patternMatch(x, m, 8));
pause();
plot(patternMatch(x, n, 8));
pause();
%}
%{
plot(patternMatch(wavread("handel.wav"), wavread("hallelujah.wav"), 10));
pause();
%}

plot(patternMatch(wavread("furelise8kHZ.wav"), wavread("cropelise8kHz.wav"), 50));
pause();


%{
%mesh(patternMatch2D(imread("page.pgm"), imread("maskM.pgm"), 10));
%pause();
%}






